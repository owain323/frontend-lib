/*
 * accordion.js — Accordion 的行为层（APG: Accordion Pattern）
 *
 * 语法刻意用 ES5（无箭头函数 / const / let / 模板字符串）——
 * 档位 A（ESP32 上的 WebView）版本不确定。
 * 也刻意不用 Element.closest / Array.filter（ES5 之后才有），理由同 tabs.js。
 *
 * 🔴 键盘契约（W3C APG 原文）
 * ------------------------------------------------
 *     Enter / Space        切换当前项
 *     Tab / Shift+Tab      在**所有**可聚焦元素之间移动（含面板内的）
 *
 * ⚠️ **不要加方向键 / Home / End** ——
 *    APG 明确写：accordion 的键盘支持里**没有**方向键
 *    （"Header navigation uses the standard Tab order; arrow / Home / End
 *      key navigation is no longer part of the APG Accordion keyboard
 *      interaction."）。
 *    那是 **Tabs** 的契约（roving tabindex）。
 *    ⇒ 很多实现照抄 tabs 给 accordion 加方向键，是把两个模式混了。
 *    ⇒ 本组件**故意不加**。
 *
 * 🔴 role="region" 的数量上限（APG 原文）
 * ------------------------------------------------
 *     "…in an accordion that contains more than **approximately 6**
 *      panels that can be expanded at the same time."
 *
 *    ⇒ 面板数 > 6 时**不**给 panel 加 role="region"，
 *      否则造成 "landmark region proliferation"（地标泛滥）。
 *    ⇒ 加 .accordion--many 即可关闭。
 */
(function () {
  'use strict';

  function toArray(x) { return Array.prototype.slice.call(x); }

  function closest(el, sel) {
    while (el && el.nodeType === 1) {
      var fn = el.matches || el.msMatchesSelector || el.webkitMatchesSelector;
      if (fn && fn.call(el, sel)) return el;
      el = el.parentNode;
    }
    return null;
  }

  function Accordion(root, opts) {
    this.root = root;
    this.opts = opts || {};
    this.items = toArray(root.querySelectorAll('.accordion__item'));
    if (!this.items.length) return;
    // 🔴 2026-10-03 把 `--multi` 从 CSS 类改成 data 属性。
    //
    //   原因：它**不是样式变体，是行为开关**。
    //   多开模式下展开的那一项，和单开模式下展开的那一项
    //   **视觉上完全一样**（都是真的展开了）——
    //   没有任何东西需要用样式去表达"这是多开模式"。
    //
    //   之前它是 class ⇒ `refs` 门禁报"class 未定义"（CSS 里确实没有）。
    //   两个选择：
    //     ① 补一条空 CSS 规则凑数 ⇒ 骗门禁，不诚实
    //     ② 改用 data 属性 ⇒ 门禁天然不报，且**语义更准确**
    //   选 ②。
    //
    //   对比 tabs--manual：那个我**给了**真实视觉差异
    //   （选中项不加粗），因为"还没生效的事不该看起来已生效"。
    //   两个决定看起来不一致，其实标准是同一个：
    //   **有没有真实的视觉差异需要表达。**
    //
    // 用法：<div class="accordion" data-accordion data-accordion-multi>
    this.single = !root.hasAttribute('data-accordion-multi')
                 && !root.classList.contains('accordion--multi');
    // >6 个面板时不给 role=region（APG 的上限）
    this.useRegion = !root.classList.contains('accordion--many') &&
                     this.items.length <= 6;
    this.init();
    this.bind();
  }

  Accordion.prototype.triggers = function () {
    return this.items.map(function (it) {
      return it.querySelector('.accordion__trigger');
    });
  };

  Accordion.prototype.panels = function () {
    return this.items.map(function (it) {
      return it.querySelector('.accordion__panel');
    });
  };

  /* 🔴 初始化：补齐 ARIA 关系。
     之所以在 JS 里补而不是要求手写：这三处（aria-controls 互指、
     heading 层号、role=region）是**机械的对应关系**，让人手写只会写错。 */
  Accordion.prototype.init = function () {
    for (var i = 0; i < this.items.length; i++) {
      var it = this.items[i];
      var btn = it.querySelector('.accordion__trigger');
      var panel = it.querySelector('.accordion__panel');
      if (!btn || !panel) continue;

      if (!panel.id) panel.id = 'acc-panel-' + (i + 1);
      if (!btn.id) btn.id = 'acc-btn-' + (i + 1);

      // ① button → panel（aria-controls）
      btn.setAttribute('aria-controls', panel.id);
      // ② panel → button（aria-labelledby）
      panel.setAttribute('aria-labelledby', btn.id);
      // ③ panel 的地标（≤6 时）
      if (this.useRegion) panel.setAttribute('role', 'region');

      // ④ heading 的 aria-level 与 h1-h6 天然隐含的一致 ⇒
      //    这里不动（用真实的 h2/h3 比显式 aria-level 更可靠）
    }
  };

  Accordion.prototype.set = function (item, open) {
    var btn = item.querySelector('.accordion__trigger');
    var panel = item.querySelector('.accordion__panel');
    if (!btn || !panel) return;
    if (btn.getAttribute('aria-disabled') === 'true') return;
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    if (open) panel.removeAttribute('hidden');
    else panel.setAttribute('hidden', '');
    if (typeof this.opts.onChange === 'function') {
      this.opts.onChange(btn, open);
    }
  };

  Accordion.prototype.toggle = function (item) {
    var opening = item.querySelector('.accordion__trigger')
                      .getAttribute('aria-expanded') !== 'true';
    if (this.single && opening) {
      // 只允许开一个 ⇒ 先全关
      var self = this;
      toArray(this.items).forEach(function (it) {
        if (it !== item) self.set(it, false);
      });
    }
    this.set(item, opening);
  };

  /* 找 trigger 所属的 item —— 自己往上走（ES5 安全的 closest） */
  Accordion.prototype.itemOf = function (btn) {
    var el = btn;
    while (el && el !== this.root) {
      if (el.className &&
          (' ' + el.className + ' ').indexOf(' accordion__item ') > -1) {
        return el;
      }
      el = el.parentNode;
    }
    return null;
  };

  Accordion.prototype.bind = function () {
    var self = this;
    this.root.addEventListener('click', function (e) {
      var btn = closest(e.target, '.accordion__trigger');
      if (!btn || !self.root.contains(btn)) return;
      if (btn.getAttribute('aria-disabled') === 'true') return;
      var item = self.itemOf(btn);
      if (item) self.toggle(item);
    });

    // 🔴 键盘：Enter / Space —— **刻意不监听 keydown**。
    //    原生 <button> 本身就响应这两个键并触发 click，
    //    写了反而**双触发**（keydown toggle 一次 + click 又 toggle 一次）。
    //    这是"用原生控件"的又一处收益：**无障碍行为免费且必然正确**。
  };

  window.Accordion = Accordion;

  function init() {
    var nodes = document.querySelectorAll('[data-accordion]');
    for (var i = 0; i < nodes.length; i++) {
      nodes[i].accordionInstance = new Accordion(nodes[i]);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
