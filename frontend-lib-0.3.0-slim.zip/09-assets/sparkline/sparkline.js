/*
 * sparkline.js — 迷你趋势图（零依赖 · ES5 · 令牌驱动）
 *
 * ============================================================================
 * 为什么自己写而不引库（2026-10-03 调研后的决定）
 * ============================================================================
 * 调研了 GitHub 上几个高质量的零依赖方案，最小的
 * `mitjafelicijan/sparklines` 是 **6390 字节 / 195 行 / gzip 1675 字节**，
 * BSD-2 许可（可商用，只需保留声明）—— 结论是**它做得很好，值得参考**。
 *
 * 但**没有直接引**，两个原因（都不是"嫌它差"）：
 *
 *   ① **它是 ES6**：`const initSparkline = (sparkline) => {...}`
 *      本库的硬约束是 **ES5**（档位 A 跑在 ESP32 的 WebView 上，
 *      版本不确定）。`const` / 箭头函数在老 WebView 上直接语法错误。
 *
 *   ② **它是 data 属性驱动 + 颜色写死**：示例里 `data-colors="gray"`
 *      或直接给 HEX。本库要求**令牌驱动**（换主题要跟着变）。
 *
 * ⇒ 所以：**借鉴它的接口设计（data 属性驱动、零依赖、BSD 思路）**，
 *   实现按本库约束重写。这不是"标准不够就自创"，
 *   是**在同一目标下按本库既定约束选实现方式**。
 *
 * ============================================================================
 * 用法
 * ============================================================================
 *   <span class="sparkline" data-spark="12,18,15,24,22,31,28"></span>
 *
 * 可选属性：
 *   data-spark-type    line（默认）| bar | area
 *   data-spark-height  像素，默认 32
 *   data-spark-color   CSS 颜色或 var(--x)，默认 var(--accent)
 *   data-spark-fill    yes（默认，area 类型填充）| no
 *   data-spark-last    yes（标出最后一个点）| no
 *   data-spark-animate yes（默认）| no
 *
 * 更新数据：
 *   el.setAttribute('data-spark', '1,2,3');
 *   Chart.emit(el);                 // 重画
 *
 * ============================================================================
 * 🔴 无障碍：这不是"图表"，是**趋势的辅助提示**
 * ============================================================================
 * 纯 SVG 火花线对读屏**没有意义**（一堆路径，读屏只会念"图像"）。
 * ⇒ 本组件**不做 role="img"**（那会让人以为它有可读的文本等价物）。
 * ⇒ **要给出可读的值**，请在旁边放一个数字或用 states 组件里的
 *   "空/错/加载"那套 —— 数字本身才是可访问的信息。
 * ⇒ 什么时候**必须**配文字：数值重要时（例如"营收 128 万，同比 +3.2%"）。
 *     纯装饰性的趋势提示（列表右侧那种小图）可以不配。
 */
(function () {
  'use strict';

  var NS = 'http://www.w3.org/2000/svg';
  var instances = [];

  /* ---------- 小工具（ES5，不用 Array.from 等） */
  function toArray(x) { return Array.prototype.slice.call(x); }
  function el(name, attrs) {
    var n = document.createElementNS(NS, name);
    if (attrs) for (var k in attrs) if (attrs.hasOwnProperty(k)) n.setAttribute(k, attrs[k]);
    return n;
  }
  function num(v, d) { var n = parseFloat(v); return isNaN(n) ? d : n; }

  /* ---------- 解析：MISSING != ZERO ----------
   *
   * 🔴 2026-10-04 修一个**真实的语义错误**（借鉴 TermDeck 的图表契约：
   *    `MISSING != ZERO / INVALID != MISSING / 过滤必须可见`）。
   *
   * 原来这里写的是：
   *     if (!isNaN(v)) out.push(v);      // 跳过空项
   * 后果有两处，都很坏：
   *   ① `"1,,3"` 变成 `1,3` ⇒ **画成一条直线**，
   *      看起来像"从 1 平滑降到 3"，实际是"1，然后**没数据**，然后 3"
   *   ② `"1,0,3"`（0 是真值）与 `"1,,3"`（缺失）**在图上完全一样**
   *      ⇒ 缺失被静默当成"没这个点"，而不是"这里没数据"
   *
   * ⇒ 改为：**空值保留为 null**，画的时候**断开**（不跨空值连线）。
   *
   * 为什么这么重要：一条**假装连续**的线会让人读出不存在的趋势
   * —— 数据缺失被当成了"平稳过渡"。这是图表最容易被忽略、
   * 也最容易误导人的一种错。
   */
  function parsePoints(spark) {
    var raw = spark.getAttribute('data-spark') || '';
    if (!raw.trim()) return [];
    var parts = raw.split(',');
    var out = [];
    for (var i = 0; i < parts.length; i++) {
      var t = parts[i].trim();
      // 空串 / 各种"无数据"写法 ⇒ null（**不是 0**）
      if (t === '' || t === '-' || t === 'null' || t === 'NaN') {
        out.push(null);
        continue;
      }
      var v = parseFloat(t);
      out.push(isNaN(v) ? null : v);   // 非法值也当 null，但**在下方标出来**
    }
    return out;
  }

  function readOpts(spark) {
    return {
      type: spark.getAttribute('data-spark-type') || 'line',
      height: num(spark.getAttribute('data-spark-height'), 32),
      color: spark.getAttribute('data-spark-color') || 'var(--accent)',
      fill: (spark.getAttribute('data-spark-fill') || 'yes') !== 'no',
      last: (spark.getAttribute('data-spark-last') || 'no') === 'yes',
      animate: (spark.getAttribute('data-spark-animate') || 'yes') !== 'no',
    };
  }

  /* ---------- 几何：算出所有 x/y ---------- */
  function scale(points, w, h, pad) {
    // 🔴 MISSING != ZERO：**求最值时必须排除 null**。
    //    Math.min(1, null, 3) === 1（null 会被当 0）——
    //    若数据全是正数，null 参与计算会把 min 拉低，图被压扁。
    var vals = [];
    for (var k = 0; k < points.length; k++) {
      if (points[k] !== null) vals.push(points[k]);
    }
    if (!vals.length) return null;          // 全是缺失 ⇒ 画不了
    var min = Math.min.apply(null, vals);
    var max = Math.max.apply(null, vals);
    // 全平的一条线：给一个人造的上下界，否则除以 0
    if (max === min) { max = min + 1; min = min - 1; }
    var span = max - min;
    var n = points.length;
    var xs = [], ys = [];
    for (var i = 0; i < n; i++) {
      xs.push(n === 1 ? w / 2 : pad + (w - pad * 2) * (i / (n - 1)));
      // 🔴 缺失点的 y 保持 null，draw() 会据此断开
      ys.push(points[i] === null ? null
              : h - pad - (h - pad * 2) * ((points[i] - min) / span));
    }
    return { xs: xs, ys: ys, min: min, max: max };
  }

  /* ---------- 动画：优先 CSS（可被 reduced-motion 关掉） ---------- */
  function supportsReducedMotion() {
    return typeof window.matchMedia === 'function' &&
           window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  }

  /* ---------- 画 ---------- */
  function draw(spark) {
    var pts = parsePoints(spark);
    var old = spark.firstChild;
    while (old) { var n = old.nextSibling; spark.removeChild(old); old = n; }
    if (pts.length < 2) return;      // 少于 2 个点画不出趋势

    var o = readOpts(spark);
    var w = spark.clientWidth || num(spark.getAttribute('data-spark-width'), 120);
    var h = o.height;
    var pad = 2;
    var s = scale(pts, w, h, pad);
    // 🔴 2026-10-04 修崩溃：scale() 在"全是缺失"时返回 null，
    //    而这里原来直接用了 s.xs ⇒ 抛 TypeError，**整个库挂掉**。
    //    （是我引入 scale 提前返回时漏了这条。）
    if (!s) return;                    // 一个有效点都没有 ⇒ 画不了，也不该画
    if (s.xs.length < 2) return;      // 只有一个有效点，画不出趋势

    var svg = el('svg', {
      width: '100%', height: h,
      viewBox: '0 0 ' + w + ' ' + h,
      preserveAspectRatio: 'none',
      // 🔴 不用 role="img"：见文件头的无障碍说明
      'aria-hidden': 'true',
      focusable: 'false',
    });

    /* 🔴 MISSING != ZERO 的落点：把序列切成**连续段**，**不跨空值连线**。
     *
     * 为什么必须这样：一条横跨缺失点的线，等于在说
     * "从 1 平滑地涨到 3，中间一切正常" —— 而真相是"中间没数据"。
     * **数据缺失被画成了平稳过渡**，这是图表最容易忽略也最会误导人的错。
     *
     * 契约来源：TermDeck 的 ChartsPage 写着
     *   「MISSING != ZERO / INVALID != MISSING / 过滤必须可见」
     * 它自己做到了 connectNulls={false} 且 0 处遗漏 —— 本库照它做。
     */
    var segs = [], cur = [];
    for (var i = 0; i < s.xs.length; i++) {
      if (s.ys[i] === null) {
        if (cur.length) segs.push(cur);
        cur = [];
      } else {
        cur.push(i);
      }
    }
    if (cur.length) segs.push(cur);

    // 有效点少于 2 个 ⇒ 画不出趋势
    var total = 0;
    for (var q = 0; q < segs.length; q++) total += segs[q].length;
    if (total < 2) { spark.appendChild(svg); return; }

    function pathOf(seg) {
      var d = 'M' + s.xs[seg[0]].toFixed(1) + ' ' + s.ys[seg[0]].toFixed(1);
      for (var t = 1; t < seg.length; t++) {
        d += 'L' + s.xs[seg[t]].toFixed(1) + ' ' + s.ys[seg[t]].toFixed(1);
      }
      return d;
    }

    // 面积填充：每段一个 path，**段间不填充**
    if (o.type === 'area' && o.fill) {
      var base = h - pad;
      for (var g = 0; g < segs.length; g++) {
        var sg = segs[g];
        if (sg.length < 2) continue;       // 单点不成"面积"
        var ad = pathOf(sg) +
                 'L' + s.xs[sg[sg.length - 1]].toFixed(1) + ' ' + base +
                 'L' + s.xs[sg[0]].toFixed(1) + ' ' + base + 'Z';
        svg.appendChild(el('path', {
          d: ad, fill: o.color, 'fill-opacity': '0.14', stroke: 'none',
        }));
      }
    }

    if (o.type === 'bar') {
      var bw = Math.max(1, (w - pad * 2) / pts.length - 1);
      for (var j = 0; j < s.xs.length; j++) {
        // 🔴 缺失点**不画柱** —— 画成 0 高度等于假装"这里是 0"
        if (s.ys[j] === null) continue;
        var bh = h - pad - s.ys[j];
        svg.appendChild(el('rect', {
          x: (s.xs[j] - bw / 2).toFixed(1), y: s.ys[j].toFixed(1),
          width: bw.toFixed(1), height: Math.max(0, bh).toFixed(1),
          fill: o.color,
          'fill-opacity': j === s.xs.length - 1 ? '1' : '0.72',
        }));
      }
    } else {
      for (var m = 0; m < segs.length; m++) {
        var seg = segs[m];
        if (seg.length === 1) {
          // 单点成段 ⇒ 画成点，否则这段"什么都不画"（用户以为图坏了）
          svg.appendChild(el('circle', {
            cx: s.xs[seg[0]].toFixed(1), cy: s.ys[seg[0]].toFixed(1),
            r: '1.5', fill: o.color,
          }));
          continue;
        }
        var path = el('path', {
          d: pathOf(seg), fill: 'none', stroke: o.color,
          'stroke-width': '1.5',
          'stroke-linecap': 'round', 'stroke-linejoin': 'round',
          'vector-effect': 'non-scaling-stroke',   // 缩放时线宽不变
        });
        if (o.animate && !supportsReducedMotion()) {
          path.setAttribute('class', 'spark-line');
        }
        svg.appendChild(path);
      }
    }

    // 标出最后一个点（"现在在哪"）
    // 🔴 末点缺失 ⇒ **不标**（标了等于假装知道末值）
    var li = s.xs.length - 1;
    if (o.last && s.ys[li] !== null) {
      svg.appendChild(el('circle', {
        cx: s.xs[li].toFixed(1), cy: s.ys[li].toFixed(1),
        r: '2.5', fill: o.color,
      }));
    }

    spark.appendChild(svg);
  }

  /* ---------- 对外 ---------- */
  var Chart = {
    draw: draw,
    emit: function (spark) { draw(spark); },
    /** 画一个区域里的所有 sparkline */
    update: function (root) {
      var list = (root || document).querySelectorAll('.sparkline[data-spark]');
      for (var i = 0; i < list.length; i++) draw(list[i]);
    },
  };
  window.Chart = Chart;

  function init() { Chart.update(); }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // 窗口尺寸变化时重画（SVG 用 viewBox，但要重算像素宽度）
  var t = null;
  window.addEventListener('resize', function () {
    if (t) clearTimeout(t);
    t = setTimeout(function () { Chart.update(); }, 150);
  });
})();
