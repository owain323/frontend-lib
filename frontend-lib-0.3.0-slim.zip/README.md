# frontend-lib

**一个慢慢打磨的前端能力库。** 目标：把我们所有前端短板一块块补上，补完的部分以后直接引用，不用每次从零想。

  - 位置：`E:/frontend-lib/`
  - 版本：**0.3.0**（见 `CHANGELOG.md`）
  - 立项：2026-10-01
  - **默认档位：C（现代浏览器）**；需要时降级到 A（ESP32 / 单文件）

### 🔴 关于"主力档位"的一次修正（2026-10-03）

这一行原先写的是「主力档位：**A（ESP32 / 单文件）**」——
定的是 ESP32，结果**整个库都被最严的那一档绑住了**：
ES5、零外部资产、只能系统字体、单文件思维。

但实际的用途是**录视频 / 做网站 / 做小程序**，
那些场景**不需要**这些限制 ⇒ **方向定错了。**

**修正后的约定**：

| | 说明 |
|---|---|
| **默认按 C 做** | 现代浏览器随便用：图标库、自定义字体、现代 CSS/JS 都行 |
| **需要 A 时降级** | ESP32 / 单文件场景，产物去掉外部依赖即可 |
| **哪些不分档** | **品味、规范、流程、无障碍判据** —— 三档通用，这是库的真正资产 |
| **哪些分档** | 技术约束：ES5、外部资产、单文件、CSS 新特性 |

**判据变了**：
以前"能不能用"看**"ESP32 允不允许"**；
现在看 **"这个场景需要吗"** —— 站点要图标库就用，ESP32 那份产物剥掉。

---

## 为什么建这个库

立库前的实测诊断（数据来自两个真实项目，不是假设）：

| 层 | 短板 | 实测证据 |
|---|---|---|
| 系统层 | 设计令牌 / 尺度模数 / 状态矩阵 | 只有颜色变量、`clamp()` 0 处、`:disabled` 0 处 |
| 适配层 | 响应式 / 无障碍纵深 / 暗色 | `@media` 仅 1 处、`prefers-reduced-motion` 0 处 |
| 结构层 | 语义层级 / 图片响应式 / 流体排版 | `<h2>` 为 0、`srcset` 0 |
| 品质层 | 信息密度 / 边界态 | 空态 0（微文案是强项，不用补） |
| 纪律层 | 视觉回归 / 真机验证 | 均无 |

**结论：缺的不是库，是系统层。** 我们已经会"选组件"（18 个库尽调、协议分档），
但还没建立"定系统"的能力。这个库就是把系统层补上。

---

## 怎么用

### 三种取用方式（按你的场景选）

| 场景 | 怎么做 | 适合谁 |
|---|---|---|
| **只要组件** | 解开 `frontend-lib-<版本>-slim.zip`，直接拷 `01-tokens` / `02-primitives` / `03-patterns` 里的 `.css` / `.js` | 常规项目 |
| **连门禁一起要** | 解开 `frontend-lib-<版本>.zip`（完整包），里面有 `05-audit/`，可以自己跑验证 | 想自己保证不跑偏 |
| **要个单文件** | 看 `04-recipes/longform/longform.html` —— 档位 A 的完整范例，**零外链**，可部署到 ESP32 | 嵌入式 / 单页 |

**两种包的区别**：

- **slim（199 KB）** — 组件 + 规范 + 范例。不含门禁脚本、经验复盘、内部路线图。
- **完整（288 KB）** — 多含 `05-audit/`（18 道门禁）、`07-notes/`（踩坑记录）、`08-plan/`（路线图）。
  想知道"我们为什么这么设计"，完整包里有过程。

**自己验一遍**（可选，但推荐）：

```bash
bash 05-audit/with-server.sh bash 05-audit/check-all.sh
# 起服务器 → 跑 18 道门禁 → 一定停掉服务器
```

### 依赖说明

- **运行时零依赖** —— 只有原生 CSS 与 ES5 JS，`tokens.css` / `typography.css` / 各组件 CSS 直接引
- **验证工具不在包里** —— `puppeteer-core` 装在 node workspace 里（库外），
  跑 `clicktest` / `accent-gate` 时需要它
- **不需要构建** —— 没有 npm install，没有打包步骤，拷走就能用

### 先读这两份，不读会乱放东西

1. `00-charter/01-入库门槛.md` — 什么能进、什么不能进
2. `00-charter/02-分层定义.md` — 分了哪些层、依赖方向

### 按你的档位取用

| 你要做什么 | 读哪份 | 怎么用 |
|---|---|---|
| ESP32 单文件页 | `03-环境档位.md` 档位 A | 复制 `04-recipes/tierA-tokens.css`（约 13.8 KB，含浅色 71 + 暗色 23 个令牌，零外链）|
| 静态站 | 档位 B | 可拆文件，可引 CDN（**必须做降级**） |
| React 项目 | 档位 C | 可引组件库，但先过协议红线 |

### 🔴 怎么看 demo（必须先读这一节）

本库的 demo **引用共享的 CSS**（`../../01-tokens/tokens.css`）——
这样才能证明组件是**可复用**的，而不是复制粘贴的死样式。

**代价是：它们必须通过 HTTP 服务器打开。**

```bash
python 05-audit/serve.py            # 起服务器并打印所有 demo 的 URL
python 05-audit/serve.py --list     # 只看清单
python 05-audit/serve.py --stop     # 用完停掉
```

| ❌ 会出问题 | ✅ 正常 |
|---|---|
| 双击 `demo.html`（`file://`）| `http://127.0.0.1:8000/...` |
| WorkBuddy 的单文件预览面板 | 上面命令打印出的 URL |

**症状对照**：如果按钮是浏览器默认样式、列表竖排、标题变成默认 h1 ——
那就是 CSS 没加载，不是页面坏了。原因是**兄弟文件 404**。

> 📌 真实踩过：长期用单文件预览看 demo，一直是无样式的，
> 却因为 `04-recipes/longform/longform.html` 是**自包含单文件**（内联 CSS）
> 显示正常，掩盖了这个问题。**一个正常样本掩盖了其他全部异常。**

---

### 六道门禁，改东西前必须跑

```bash
python 05-audit/contrast.py            # 对比度：不达标不许入库
python 05-audit/states.py   --dir .    # 状态矩阵：缺 disabled / focus-visible 就是 HIGH
python 05-audit/refs.py     --dir .    # 引用完整性：class 写错时页面不报错，只是静默失效
python 05-audit/a11y.py     --dir .    # 无障碍：label 关联 / img alt / 标题层级
python 05-audit/viewport.py --dir .    # 响应式：meta viewport / 固定宽度 / img 缺尺寸
python 05-audit/md-render.py x.md --check   # 内容渲染：标题层级 / alt / 表格语义
```

⚠️ `states` / `refs` / `a11y` / `viewport` **必须 `--dir` 扫全目录**。
`.field` 的态在 `input.css` 里，单扫一个文件会误报"缺 disabled/focus"。

**每道门禁的实战战绩**（都是真抓到的，不是设想）：

| 门禁 | 抓到过什么 |
|---|---|
| contrast | 首版 5 项不达标 |
| states | SpendLatch 16 项 HIGH；`choice` 形态上线即抓出 3 个卡片类缺 focus |
| refs | `input/demo.html` 用了 `.btn` 却没 link `button.css`（按钮静默变浏览器默认样式）|
| a11y | `choice/demo.html` 的 `<select>` 缺 label；选择控件的证据标记丢身份 |
| viewport | `viewport.py` 自身 glob 漏扫全部 CSS（元组长度不匹配导致崩溃）|
| md-render | 表格在纯 CommonMark 下会静默失效（渲染成 `<p>`）|

### 🔴 门禁自己也要被验证（防假绿）

**每一道**都做了双向控制：跑在已知有问题的代码上必须报错，
跑在库自己的代码上必须通过。任何一边不成立，说明脚本坏了 ——
**假绿比不检查更糟**，因为它会让你以为没问题。

---

## 目录

| 目录 | 装什么 | 状态 |
|---|---|---|
| `00-charter/` | 入库门槛、分层定义、环境档位 | ✅ 完成 |
| `01-tokens/` | 颜色/间距/字号/动效/z-index | ✅ 第一版（色板已实测） |
| `02-primitives/` | 原子组件 + 状态矩阵 | 🔶 button / input / card / choice ✅（各带 `demo.html`） |
| `03-patterns/` | 列表、表单、空态、加载、错误 | 🔶 容器四态 / 表单校验 / 反馈层 ✅ |
| `04-recipes/` | 长文页 / 数据看板 / 对话界面 / 作品集 | ⬜ 未开始 |
| `05-audit/` | 自检脚本 | 🔶 3/5（contrast / states / refs） |
| `06-vendor/` | 第三方协议台账（不存源码） | ✅ 24 项已核实 |
| `07-notes/` | 取舍笔记 | ⬜ 未开始 |

---

## 已沉淀的关键判断（别重复踩坑）

- **边框要分两类**：`control`（控件边界，WCAG 1.4.11 要求 ≥3.0）vs `decor`（装饰分隔，不强制）。
  对装饰线强求 3.0 会把界面做得很重 —— 那是误读规范。
- **npm 解包体积 ≠ 浏览器直引体积**，差 10 倍（`motion` 741 KB → 实际 144 KB）。
- **协议要逐版本查**：`animal-island-ui` 2.0.0 才转 MIT，之前全是禁商用的 CC-BY-NC-4.0。
- **不要用 `sublicense` 当限制词 grep** —— 它是标准 MIT 自带词，会误报所有干净库。
- **动效一源原则**：一个项目只用一组时长和缓动，否则六个效果六条曲线，看起来像没设计过。
- **"九态"不是每个组件都九态**：按钮取七态（default/hover/active/focus-visible/disabled/busy/success），
  input 取五态（hover/focus/disabled/readonly/error），
  容器取四态（content/empty/loading/error）。按钮没有"空"，**input 没有 active**（不响应按压），容器不响应按压。
- **button 用 `:focus-visible`，input 用 `:focus`** —— 鼠标点 input 时用户也必须知道光标在哪；
  鼠标点 button 时不该冒出难看的框。搞反了表单会非常难用。
- **input 字号必须 ≥16px** —— iOS Safari 在小于 16px 时会自动放大整个页面且不缩回。硬下限，不是审美。
- **卡片 hover 只改 `transform` 和 `box-shadow`** —— 改 `border-width`/`margin`/`padding` 会引起回流，
  相邻卡片跟着抖 1px，轻到说不清哪里不对但整页显廉价。要"加粗"边框用 inset box-shadow。
- **整卡可点必须内嵌真实 `<a>`** —— 给 div 加 onclick：键盘 Tab 不到、屏幕阅读器不认、
  不能中键新开。焦点用 `:focus-within` 让整卡显示 ring。
- **容器四态每态都要给出出口** —— empty 没有动作按钮 = 把用户卡死；
  error 没有重试 = 死路（刷新往往解决不了问题）。
- **reduced-motion 下 spinner 保留、骨架屏停止** —— 同样是"加载中动画"处理相反，
  判断依据是**去掉后是否损失信息**：spinner 停了以为卡死；骨架屏静态占位仍传达"内容在来"。
- **请求 <300ms 不显示加载态** —— 闪一下比不显示更糟。延迟 300ms 再显示。
- **表单不要在 `oninput` 报错** —— 用户刚敲第一个字符就变红，打到一半满屏红字会直接放弃填表。
  三层时机：`onblur` 首次 → 脏了才实时 → `onsubmit` 全量 + 错误汇总。
- **提交失败和成功后焦点都要移走** —— 留在提交按钮上，用户按 Enter 会重复提交。
- **档位 A 禁用 `:has()`** —— CSS Level 4，ESP32 上 WebView 版本不确定；
  且把"何时校验"这种逻辑塞进样式层不可测。控制权交给 JS 加类。
- **`states.py` 必须 `--dir` 扫全目录** —— `.field` 的态在 `input.css` 里，
  单扫一个文件会误报"缺 disabled/focus"。
- **选择控件绝不 `display:none` 隐藏原生 input** —— 那会把它从 tab 顺序移除，
  键盘用户彻底到不了，而**用鼠标测完全测不出来**。
- **焦点环必须画在看得见的元素上** —— input 是 `opacity:0` 的，它自己的 outline 看不见。
  门禁的 choice 形态只认 `:focus-visible +` 这种相邻兄弟写法。
- **同族元素用 BEM 的 `__`，不要用 `-`** —— `-` 是修饰符（`--`）。
  写成 `.choice-group` 会让容器脱离根类、状态归组失效。门禁反过来纠正过我一次。
- **toast 和 dialog 是两种东西** —— 判据只有一条：用户不做任何操作，任务能不能继续。
  能 → toast；不能 → dialog。把"确认删除"做成 toast 是严重错误。
- **锁背景滚动必须补偿滚动条宽度** —— 否则内容横向跳一下。
  弹层"闪"的感觉大半来自这个，而不是动画没做好。
- **危险操作初始焦点给"取消"、点遮罩不关闭** —— 用户看清标题之前条件反射按 Enter 不该出事。
- **库代码用 ES5，demo 才可以用现代语法** —— 档位 A 是 ESP32 上的 WebView，版本不确定。
- **门禁必须有双向控制**：跑在已知有问题的代码上要报错，跑在自己代码上要通过。
  只做一边就是假绿。
- **`disabled` 和 `aria-disabled` 不是同义词**：前者从 Tab 顺序移除，
  表单提交按钮该用后者 —— 用户 Tab 到它才知道"还差点什么"。
- **spinner 要豁免 `prefers-reduced-motion`**：reduced-motion 针对大幅位移，
  原地旋转不属于此类。停掉它用户会以为卡死。放慢但保留。

---

## 下一步（按顺序来，不跳）

1. ✅ `02-primitives` 的 button — 七态 + demo
2. ✅ `02-primitives` 的 input/field — 五态 + demo（含无障碍清单）
3. ✅ `02-primitives` 的 card — hover 无跳动判据已做成 demo
4. ✅ `03-patterns` 容器四态 — empty / loading / error / success（"空态 0"的直接对应）
5. ✅ `03-patterns` 表单校验 — 三层时机 + 错误汇总 + 焦点管理
6. ✅ `02-primitives` 的 choice（checkbox / radio / select）— 原生键盘行为全部保留
7. ✅ `03-patterns` 反馈层（toast + dialog）— focus trap / 焦点归还 / 滚动锁定
8. `05-audit` 补 `viewport.py`（320px 取证）、`a11y.py`（label 关联 / alt / 按钮文本）
9. **`04-recipes` 长文阅读页** — ESP32 档位 A 单文件，个人站实际需求
4. `04-recipes/长文阅读页` — 个人站实际需求，边做边验 token
5. `05-audit` 补 `viewport.py`（320px 渲染取证）、`motion.py`（reduced-motion 兜底检查）

---

## 纪律

- 凭感觉填的色不许入库，必须带着 `contrast.py` 的实测数字
- 说不出反例的东西不许入库
- 源码不进 `06-vendor/`，只记台账
- 半年没被引用过的条目移到 `99-attic/`
