# 决策：收敛到 GitHub Primer

> 2026-10-03 · Owner 已批准方向（收敛到 Primer，官方名 + 简写别名，色值换官方值）
> **本文档是"落地前的最后一道"** —— 下面是实测数据与三个必须先定的分歧点。

---

## 为什么要收敛（真实数据，不是判断）

派 agent 只读调查了四个项目，**实测确认**：

| 项目 | 令牌体系 | 对 frontend-lib 的引用 |
|---|---|---|
| ChronosDeck | `--ink --muted --line --blue`（GitHub Primer 风格）| **0 处** |
| CostPilot | `--ink --muted --line --blue`（同上）| **0 处** |
| TermDeck | `--gray-50…700`（自研暖灰金融终端）| **0 处** |
| TermDeck-backtest | 纯 Python，无前端 | — |

🔴 **frontend-lib 是零消费者，而它自己是四套体系里最"独特"的那套（自创命名）。**
Owner 那句「不能因标准不够就自创一套」—— 现状比这更严重：**割裂已经发生了。**

---

## 好消息：结构天然对齐

| frontend-lib | Primer 官方 | ChronosDeck / CostPilot |
|---|---|---|
| `--paper` | `--bgColor-default` | `--bg` |
| `--surface` | `--bgColor-muted` | `--bg2` |
| `--surface-sunken` | `--bgColor-inset` | （无，用 `--bg2`）|
| `--text-primary` | `--fgColor-default` | `--ink` |
| `--text-secondary` | `--fgColor-muted` | `--muted` |
| `--text-tertiary` | `--fgColor-subtle` | `--muted2` |
| `--accent` | `--fgColor-accent` | `--blue` |
| `--accent-soft` | `--bgColor-accent-muted` | `--blue-weak` |
| `--success` / `--danger` / `--warning` | `--fgColor-success` / `danger` / `attention` | `--green` / `--red` / `--amber` |
| `--danger-bg` 等 4 个淡底 | `--bgColor-*-muted` | `--red-weak` 等 |
| `--border-control` | `--borderColor-default` | `--line2` |
| `--border-decor` | `--borderColor-muted` | `--line` |
| `--border-decor-str` | `--borderColor-subtle` | （无）|

✅ **边框三分对三级** —— 我和 Primer 的结构本来就一样，只有命名不同。
✅ **22 个令牌全部能对上**，只有 3 个项目里没有对应物（`--text-on-accent` / `--border-decor-str` / `--bgColor-overlay`）。

---

## 🔴 分歧点一：Primer 官方的暗色 `fg-subtle` 本身不及格

**实测（WCAG 公式，门槛 4.5:1）**：

| 底色 | Primer `#6e7681` |
|---|---|
| `--bgColor-default` #0d1117 | 4.12 ❌ |
| `--bgColor-muted` #161b22 | 3.77 ❌ |
| `--bgColor-inset` #010409 | 4.47 ❌ |
| `--bgColor-success-muted` #0f2913 | **3.39 ❌** |
| `--bgColor-accent-muted` #121d2f | 3.68 ❌ |

**⇒ Primer 官方的暗色弱文字在深底上全线不及格。**
（浅色模式全部通过，最低 4.57。）

**解法**：在 Primer 灰阶里往上找第一个合格的：

| 候选 | 最低对比度 | 判定 |
|---|---|---|
| `#6e7681`（官方原值）| 3.39 | ❌ |
| `#7d8590` | 4.18 | ❌ 还差一点 |
| **`#848d97`** | **4.63** | ✅ **建议用这个** |
| `#8b949e` | 5.07 | ✅ 更保守 |

**建议：暗色 `--fgColor-subtle` 用 `#848d97`（Primer 灰阶内的值，不是自创色）。**
代价：与 Primer 官网显示略有差异；收益：暗色弱文字真正可读。

**⚠️ 这意味着"完全等于 Primer 官方值"做不到** —— 官方暗色有一个色不过 WCAG AA。
要么接受这个偏差，要么放弃"弱文字在暗色下可读"。**我建议前者。**

---

## 🔴 分歧点二：色值来源需要核对

**上面用的 Primer 值是我从公开资料查到的，不是从 primer.style 官方源码核对的。**
落地前必须逐个核对官方出处 —— 否则又是"我以为的标准"。

**核对方式**：读 `@primer/primitives` 的 npm 包（离线可查），或读 primer.style 的 CSS。

---

## 🔴 分歧点三：Primer 有 9 套主题，我只有 2 套

| Primer | frontend-lib |
|---|---|
| light ✅ | light ✅ |
| dark ✅ | dark ✅ |
| **light_high_contrast** | ❌ |
| **dark_high_contrast** | ❌ |
| **light_colorblind / tritanopia** | ❌ |
| **dark_colorblind / tritanopia** | ❌ |
| **dimmed** | ❌ |

🔴 **高对比与色盲友好那 4 套，恰恰是无障碍最关心的** ——
而我今晚给无障碍打 8.0 分时，**读屏是零验证**。

**这是"收敛到 Primer"能白拿的最大好处**：不是我做出 4 套主题，
而是**以后要 4 套时，Primer 已经有了**。

---

## 落地顺序（还没动手，等确认）

1. **核对官方色值**（从 npm 包或官网，不靠公开资料）
2. **只改色值，不改命名** → 跑门禁（`contrast` / `dark-gate` 会红，因为实测数字全变）
3. **按实测结果微调个别值**（已知要调暗色 `fg-subtle`）
4. **再加官方名 + 简写别名**（`--fgColor-default: var(--ink)` 这样，组件内部只用一个）
5. **同步档位 A 的内联副本**
6. **全量门禁 + 截图对比**
7. **写 `00-charter/` 的令牌决策记录**（把"为什么收敛"和"哪一处偏离了官方"写清楚）

⚠️ **不改组件类名**（`.btn` / `.field__input` 等）—— 那是另一件事，
而且组件类名与 Primer 的差异是**语义差异**（BEM vs Primer 的命名），
不该在这次一起动。

---

## 我的建议

**先做第 1 步（核对官方色值）**，因为后面每一步都依赖它。
核对完如果色值与我查到的有出入，**整张表要重算**。

**在你说"开始"之前我不动文件。**
