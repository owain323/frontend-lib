const puppeteer = require('puppeteer-core');
const AXE = require.resolve('axe-core');

// 反向控制：注入 5 类典型违规，验证 axe 是否真能抓到（否则"0 违规"不可信）
const CASES = [
  ['image-alt', '<img src="x.png">'],
  ['label', '<input type="text">'],
  ['duplicate-id', '<div id="dup"></div><div id="dup"></div>'],
  ['tabindex', '<div tabindex="5">焦点乱序</div>'],
  ['color-contrast', '<p style="color:#bbbbbb;background:#ffffff">太浅的文字</p>'],
];

(async () => {
  const b = await puppeteer.launch({
    executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe',
    headless: 'new', args: ['--no-sandbox', '--disable-gpu'],
  });
  const p = await b.newPage();
  await p.setViewport({ width: 1280, height: 900 });
  await p.goto('http://127.0.0.1:8000/02-primitives/input/demo.html',
               { waitUntil: 'networkidle0' });
  await p.evaluate((html) => {
    document.body.insertAdjacentHTML('beforeend', html);
  }, CASES.map(([, h]) => h).join('\n'));
  await p.addScriptTag({ path: AXE });
  const v = await p.evaluate(async () => {
    const res = await window.axe.run(document);
    const out = {};
    res.violations.forEach((x) => { out[x.id] = x.nodes.length; });
    return out;
  });
  console.log('  注入 5 类违规，axe 结果：');
  let miss = 0;
  for (const [id] of CASES) {
    const n = v[id];
    if (!n) miss++;
    console.log('    ' + (n ? 'OK ' : 'NG ') + ' ' +
                id.padEnd(16) + (n ? '×' + n : ' <<< 漏检'));
  }
  await b.close();
  console.log('');
  console.log(miss ? '  ' + miss + ' 类漏检' : '  5/5 全部抓到 —— 说明"0 违规"是可信的');
  process.exit(miss ? 1 : 0);
})();
