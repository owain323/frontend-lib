#!/usr/bin/env bash
# check-all.sh — 跑全部门禁，一条命令
#
# 🔴 2026-10-03 建的。理由：这一晚我漏了 `--dir .` 参数，
#    6 道门禁假报 FAIL —— **手动敲 16 条命令本身就是不可靠的**。
#    门禁的价值在于"每次都跑"，跑不全等于没有。
set -u
cd "$(dirname "$0")/.." || exit 2
PY="python"
NODE_DIR="/c/Users/czj17751/.workbuddy/binaries/node/versions/22.17.0"
[ -x "$NODE_DIR/node" ] && export PATH="$NODE_DIR:$PATH"
# axe-core / puppeteer-core 装在库外的 node workspace（不��发布包带走）
export NODE_PATH="/c/Users/czj17751/.workbuddy/binaries/node/workspace/node_modules"

fail=0
run() {  # run <名字> <命令...>
  local name="$1"; shift
  if out=$("$@" 2>&1); then
    printf '  %-16s PASS\n' "$name"
  else
    printf '  %-16s FAIL\n' "$name"
    echo "$out" | grep -E '^\s*\[|不达标|不符|未定义|未门控|需人工|超' | head -6 | sed 's/^/       /'
    fail=$((fail+1))
  fi
}

echo "=== 静态门禁 ==="
run "contrast"   $PY 05-audit/contrast.py
run "cmp-contrast" $PY 05-audit/component-contrast.py
run "tierA-sync" $PY 05-audit/make-tiersnippet.py --check
run "start-here" $PY 05-audit/fix-start-here.py --check
run "hygiene"    $PY 05-audit/hygiene.py
run "shot-path"  $PY 05-audit/shot-path.py
run "deps"      $PY 05-audit/deps.py --missing
for g in states refs a11y viewport motion switch; do
  run "$g"       $PY "05-audit/$g.py" --dir .
done
for g in es5-gate tierA-gate icon-gate hover-gate measure-gate license-gate numeric-gate dark-gate hardcode-gate reuse-check _docclaims; do
  run "$g"       $PY "05-audit/$g.py" --dir .
done

echo ""
echo "=== 浏览器门禁（需要 127.0.0.1:8000）==="
run "accent-gate" $PY 05-audit/accent-gate.py
run "perf-gate"   node 05-audit/perf-gate.js
run "switch"     node 05-audit/switch-contract.js
run "tabs"       node 05-audit/tabs-contract.js
run "accordion"  node 05-audit/accordion-contract.js
run "sparkline"  node 05-audit/sparkline-contract.js
run "a11y-scan"   node 05-audit/a11y-scan.js
run "clicktest"   node 05-audit/clicktest.js
run "selftest"    $PY 05-audit/selftest.py

echo ""
echo "=== 死类报告（只报告，不 fail：判据需要人判断）==="
$PY 05-audit/dead-class-gate.py | sed 's/^/  /'

echo ""
if [ "$fail" -eq 0 ]; then
  echo "全部通过。"
else
  echo "$fail 道门禁失败。"
fi
exit $fail
