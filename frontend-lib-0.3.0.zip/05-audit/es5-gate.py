#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
es5-gate.py — 库代码的语法必须是 ES5

背景（2026-10-03）
------------------
档位 A 是 **ESP32 上的 WebView，版本不确定**。
所以 `01-tokens` / `02-primitives` / `03-patterns` 里的**库代码**必须只用 ES5 ——
ES6+ 在老 WebView 上是**语法错误**（整段脚本不执行，而不是降级）。

🔴 这条约束**曾经只写在各个 .js 的注释里**（「语法刻意用 ES5」），
**charter 里没有、也没有任何门禁在守** ——
典型的「看起来有约定，实际没人管」。
现收口到 charter + 本门禁。

**豁免**：`demo.html` 与 `04-recipes/**` 可以用现代语法 ——
它们是给人读的说明材料与自包含范例，**不部署到设备**。

判据
----
库代码里出现以下之一即失败：
  · `const` / `let`（词边界，排除注释里的文字）
  · 箭头函数 `=>`
  · 模板字符串（反引号）
  · 展开/剩余 `...`
  · `class` / `async` / `await`
  · 可选链 `?.` / 空值合并 `??`
  · CSS 里的 `:has()`

用法：python 05-audit/es5-gate.py

———
🔴 附：为什么本库**不能**对 `border-left: 2px+` 做一刀切
------------------------------------------------
Owner 评价提示框的左侧竖条"很蠢"，已从全库去掉。
但扫全库时会发现还剩 5 处 —— **它们必须留着**，逐条判定如下：

| 位置 | 选择器 | 为什么留 |
|---|---|---|
| `content.css` + `longform` ×3 | `.prose > blockquote` | **引言块的竖条是排版惯例**（Markdown 渲染出来就是这样），去掉就跟别的文档站长得不一样了 |
| `content.css` + `longform` | `.prose > pre` | 代码块的"左侧边线"同样属于代码块语汇，且配合 `border-radius: 0 r-sm r-sm 0` 的不对称圆角 |
| `nav.css` | `.toc__link` | 目录树的**层级指示线**，是"这在目录里的第几层"的信息，不是装饰 |

⇒ 判据：**竖条是"结构指示"就留，是"纯装饰"就去。**
本门禁不做这条检查（判断需要语义），只在注释里记下判据。
"""
import sys
import os
import re
import glob

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LIB_DIRS = ('01-tokens', '02-primitives', '03-patterns')

# 逐条：正则 + 说明
JS_RULES = [
    (re.compile(r'(?<![\w$.])const\s'), 'const'),
    (re.compile(r'(?<![\w$.])let\s'), 'let'),
    (re.compile(r'=>'), '箭头函数'),
    (re.compile(r'`'), '模板字符串'),
    (re.compile(r'\.\.\.'), '展开/剩余'),
    (re.compile(r'(?<![\w$.])class\s'), 'class'),
    (re.compile(r'(?<![\w$.])async\s'), 'async'),
    (re.compile(r'(?<![\w$.])await\s'), 'await'),
    (re.compile(r'\?\.', re.S), '可选链 ?.'),
    (re.compile(r'\?\?', re.S), '空值合并 ??'),
]
CSS_RULES = [
    (re.compile(r':has\('), ':has()'),
]


def strip_comments_js(src):
    src = re.sub(r'/\*.*?\*/', lambda m: '\n' * m.group(0).count('\n'),
                  src, flags=re.S)
    src = re.sub(r'(?<![:"\'])//[^\n]*', '', src)
    src = re.sub(r'(["\'])(?:\\.|(?!\1)[^\\\n])*\1', lambda m: '""', src,
                  flags=re.S)          # 字符串字面量
    return src


def strip_comments_css(src):
    return re.sub(r'/\*.*?\*/', lambda m: '\n' * m.group(0).count('\n'),
                  src, flags=re.S)


def main():
    root = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else ROOT
    issues = []
    files = 0
    for base in LIB_DIRS:
        for f in glob.glob(os.path.join(root, base, '**', '*.js'),
                           recursive=True):
            files += 1
            src = strip_comments_js(open(f, encoding='utf-8').read())
            for line_no, ln in enumerate(src.split('\n'), 1):
                for pat, name in JS_RULES:
                    if pat.search(ln):
                        issues.append((os.path.relpath(f, root).replace('\\', '/'),
                                       line_no, name, ln.strip()[:50]))
        for f in glob.glob(os.path.join(root, base, '**', '*.css'),
                           recursive=True):
            files += 1
            src = strip_comments_css(open(f, encoding='utf-8').read())
            for line_no, ln in enumerate(src.split('\n'), 1):
                for pat, name in CSS_RULES:
                    if pat.search(ln):
                        issues.append((os.path.relpath(f, root).replace('\\', '/'),
                                       line_no, name, ln.strip()[:50]))

    for rel, ln, name, txt in issues:
        print('  [es5-gate] %-34s L%-4d %-12s %s' % (rel, ln, name, txt))
    print('')
    if issues:
        print('%d 处 ES6+ —— 档位 A 的老 WebView 上会**语法错误**（脚本整段不执行）。' % len(issues))
        print('  改法：换回 ES5 写法（var + function + 字符串拼接）。')
        return 1
    print('ES5 合规：%d 个库文件全部通过（demo 与 recipe 豁免）。' % files)
    return 0


if __name__ == '__main__':
    sys.exit(main())
